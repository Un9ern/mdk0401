from django.contrib import admin
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from apps.catalog.api import BookViewSet
from apps.readers.api import ReaderViewSet
from apps.circulation.api import LoanViewSet
from apps.reports.api import KPIView
from apps.accounts.views import login_view, logout_view
from apps.catalog.views import dashboard_redirect, book_list, book_create, book_edit, book_delete
from apps.readers.views import reader_list, reader_create, reader_edit, reader_toggle
from apps.circulation.views import loan_list, loan_create, loan_return
from apps.reports.views import report_dashboard, export_csv

router = DefaultRouter()
router.register('books', BookViewSet, basename='api-books')
router.register('readers', ReaderViewSet, basename='api-readers')
router.register('loans', LoanViewSet, basename='api-loans')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', dashboard_redirect, name='home'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('books/', book_list, name='book-list'),
    path('books/add/', book_create, name='book-create'),
    path('books/<int:pk>/edit/', book_edit, name='book-edit'),
    path('books/<int:pk>/delete/', book_delete, name='book-delete'),
    path('readers/', reader_list, name='reader-list'),
    path('readers/add/', reader_create, name='reader-create'),
    path('readers/<int:pk>/edit/', reader_edit, name='reader-edit'),
    path('readers/<int:pk>/toggle/', reader_toggle, name='reader-toggle'),
    path('loans/', loan_list, name='loan-list'),
    path('loans/add/', loan_create, name='loan-create'),
    path('loans/<int:pk>/return/', loan_return, name='loan-return'),
    path('reports/', report_dashboard, name='reports'),
    path('reports/export.csv', export_csv, name='reports-export'),
    path('api/', include(router.urls)),
    path('api/reports/kpi/', KPIView.as_view(), name='api-kpi'),
    path('api/auth/token/', TokenObtainPairView.as_view(), name='token-obtain-pair'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
]
