@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher not found. Install Python 3.12+ and enable PATH.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 py -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Could not install dependencies. Check internet connection and try again.
  pause
  exit /b 1
)
python manage.py makemigrations accounts catalog readers circulation
if errorlevel 1 goto fail
python manage.py migrate
if errorlevel 1 goto fail
python manage.py seed_demo
if errorlevel 1 goto fail
echo.
echo Opening http://127.0.0.1:8000/ . Stop the server with Ctrl+C.
start "" http://127.0.0.1:8000/
python manage.py runserver 127.0.0.1:8000
goto end
:fail
echo Startup failed. Review the error message above.
pause
:end
endlocal
