from django.db.models import Count, Sum
from django.utils import timezone
from apps.catalog.models import Book
from apps.readers.models import Reader
from apps.circulation.models import Loan

def get_kpi():
    today = timezone.localdate()
    book_stats = Book.objects.aggregate(titles=Count('id'), copies=Sum('total_copies'), available=Sum('available_copies'))
    return {
        'book_titles': book_stats['titles'] or 0,
        'total_copies': book_stats['copies'] or 0,
        'available_copies': book_stats['available'] or 0,
        'checked_out_copies': (book_stats['copies'] or 0) - (book_stats['available'] or 0),
        'active_readers': Reader.objects.filter(active=True).count(),
        'open_loans': Loan.objects.filter(returned_at__isnull=True).count(),
        'overdue_loans': Loan.objects.filter(returned_at__isnull=True, due_date__lt=today).count(),
        'due_today': Loan.objects.filter(returned_at__isnull=True, due_date=today).count(),
        'returned_total': Loan.objects.filter(returned_at__isnull=False).count(),
    }

def get_category_totals():
    rows = Book.objects.values('category').annotate(titles=Count('id'), copies=Sum('total_copies')).order_by('-copies', 'category')
    max_total = max((r['copies'] or 0 for r in rows), default=1) or 1
    return [{**row, 'bar_width': int((row['copies'] or 0) * 100 / max_total)} for row in rows]
