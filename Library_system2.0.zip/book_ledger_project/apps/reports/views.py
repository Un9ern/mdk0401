import csv
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render
from django.utils import timezone
from apps.catalog.models import Book
from apps.circulation.models import Loan
from .services import get_kpi, get_category_totals

@login_required
def report_dashboard(request):
    kpi = get_kpi()
    recent_loans = Loan.objects.select_related('book', 'reader').order_by('-issued_on', '-id')[:8]
    overdue = Loan.objects.select_related('book', 'reader').filter(returned_at__isnull=True, due_date__lt=timezone.localdate()).order_by('due_date')[:8]
    low_stock = Book.objects.filter(available_copies__lte=2).order_by('available_copies', 'title')[:6]
    return render(request, 'reports/dashboard.html', {
        'kpi': kpi, 'recent_loans': recent_loans, 'overdue': overdue,
        'low_stock': low_stock, 'category_totals': get_category_totals(),
    })

@login_required
def export_csv(request):
    response = HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition'] = 'attachment; filename="book_inventory.csv"'
    response.write('\ufeff')
    writer = csv.writer(response, delimiter=';')
    writer.writerow(['Название', 'Автор', 'ISBN', 'Жанр / раздел', 'Издательство', 'Год', 'Полка', 'Всего экземпляров', 'Доступно', 'На руках'])
    for book in Book.objects.order_by('title'):
        writer.writerow([book.title, book.author, book.isbn or '', book.category, book.publisher, book.publication_year or '', book.shelf, book.total_copies, book.available_copies, book.total_copies - book.available_copies])
    return response
