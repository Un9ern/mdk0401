from datetime import timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.db.models import F
from django.utils import timezone
from apps.catalog.models import Book
from apps.readers.models import Reader
from apps.circulation.models import Loan

class Command(BaseCommand):
    help = 'Создаёт демонстрационные записи и тестовую учётную запись сотрудника.'

    def handle(self, *args, **options):
        User = get_user_model()
        user, created = User.objects.get_or_create(username='admin', defaults={
            'first_name': 'Главный', 'last_name': 'Библиотекарь', 'email': 'admin@example.local',
            'role': User.Role.ADMIN, 'is_staff': True, 'is_superuser': True,
        })
        if created:
            user.set_password('admin12345')
            user.save()
            self.stdout.write(self.style.WARNING('Создан демонстрационный вход: admin / admin12345. Измените пароль после первого входа.'))
        books_data = [
            ('Мастер и Маргарита', 'Михаил Булгаков', '9785171492285', 'Классика', 'АСТ', 2022, 'A-01', 4),
            ('Преступление и наказание', 'Фёдор Достоевский', '9785170907294', 'Классика', 'АСТ', 2021, 'A-02', 3),
            ('Дюна', 'Фрэнк Герберт', '9785040997523', 'Фантастика', 'Эксмо', 2020, 'B-01', 5),
            ('1984', 'Джордж Оруэлл', '9785171357465', 'Антиутопия', 'АСТ', 2021, 'B-02', 2),
            ('Маленький принц', 'Антуан де Сент-Экзюпери', '9785389074343', 'Проза', 'Азбука', 2019, 'C-01', 4),
            ('Sapiens. Краткая история человечества', 'Юваль Ной Харари', '9785001311367', 'Нон-фикшн', 'Синдбад', 2022, 'D-01', 3),
            ('Гарри Поттер и философский камень', 'Джоан Роулинг', '9785389077702', 'Фэнтези', 'Махаон', 2021, 'B-03', 4),
            ('Три товарища', 'Эрих Мария Ремарк', '9785171146806', 'Классика', 'АСТ', 2020, 'A-03', 2),
        ]
        book_map = {}
        for title, author, isbn, category, publisher, year, shelf, copies in books_data:
            book, _ = Book.objects.get_or_create(isbn=isbn, defaults={
                'title': title, 'author': author, 'category': category, 'publisher': publisher,
                'publication_year': year, 'shelf': shelf, 'total_copies': copies,
            })
            book_map[title] = book
        readers_data = [
            ('Анна Смирнова', 'ЧТ-0001', 'anna@example.local', '+7 900 111-22-33'),
            ('Иван Петров', 'ЧТ-0002', 'ivan@example.local', '+7 900 222-33-44'),
            ('Мария Волкова', 'ЧТ-0003', 'maria@example.local', '+7 900 333-44-55'),
            ('Алексей Орлов', 'ЧТ-0004', 'alex@example.local', '+7 900 444-55-66'),
            ('Елена Кузнецова', 'ЧТ-0005', 'elena@example.local', '+7 900 555-66-77'),
        ]
        reader_map = {}
        for name, card, email, phone in readers_data:
            reader, _ = Reader.objects.get_or_create(card_number=card, defaults={'full_name': name, 'email': email, 'phone': phone, 'active': True})
            reader_map[card] = reader
        if not Loan.objects.exists():
            today = timezone.localdate()
            # Two current loans and one overdue loan demonstrate stock updates and reporting.
            first = book_map['Дюна']
            Loan.objects.create(book=first, reader=reader_map['ЧТ-0001'], issued_on=today - timedelta(days=3), due_date=today + timedelta(days=11), issued_by=user, notes='Демонстрационная выдача')
            Book.objects.filter(pk=first.pk).update(available_copies=F('available_copies') - 1)
            second = book_map['Мастер и Маргарита']
            Loan.objects.create(book=second, reader=reader_map['ЧТ-0002'], issued_on=today - timedelta(days=7), due_date=today + timedelta(days=7), issued_by=user, notes='Демонстрационная выдача')
            Book.objects.filter(pk=second.pk).update(available_copies=F('available_copies') - 1)
            overdue_book = book_map['1984']
            Loan.objects.create(book=overdue_book, reader=reader_map['ЧТ-0003'], issued_on=today - timedelta(days=28), due_date=today - timedelta(days=14), issued_by=user, notes='Демонстрационная просрочка')
            Book.objects.filter(pk=overdue_book.pk).update(available_copies=F('available_copies') - 1)
        self.stdout.write(self.style.SUCCESS(f'Демонстрационные записи подготовлены: книг — {Book.objects.count()}, читателей — {Reader.objects.count()}, операций — {Loan.objects.count()}.'))
