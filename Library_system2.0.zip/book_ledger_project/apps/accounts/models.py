from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = 'admin', 'Администратор'
        LIBRARIAN = 'librarian', 'Библиотекарь'
    role = models.CharField('Роль', max_length=20, choices=Role.choices, default=Role.LIBRARIAN)

    class Meta:
        verbose_name = 'Сотрудник'
        verbose_name_plural = 'Сотрудники'

    def __str__(self):
        return self.get_full_name() or self.username
