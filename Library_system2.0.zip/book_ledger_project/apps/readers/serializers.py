from rest_framework import serializers
from apps.circulation.models import Loan
from .models import Reader

class ReaderSerializer(serializers.ModelSerializer):
    def validate_active(self, value):
        if self.instance and self.instance.active and not value:
            if Loan.objects.filter(reader=self.instance, returned_at__isnull=True).exists():
                raise serializers.ValidationError('Нельзя отключить читателя: за ним числятся выданные книги.')
        return value

    class Meta:
        model = Reader
        fields = ['id', 'full_name', 'card_number', 'email', 'phone', 'active', 'registered_at']
        read_only_fields = ['registered_at']
