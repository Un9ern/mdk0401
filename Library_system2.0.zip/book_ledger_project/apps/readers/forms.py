from django import forms
from .models import Reader

class ReaderForm(forms.ModelForm):
    class Meta:
        model = Reader
        fields = ['full_name', 'card_number', 'email', 'phone', 'active']
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Фамилия Имя Отчество'}),
            'card_number': forms.TextInput(attrs={'placeholder': 'ЧТ-0001'}),
            'email': forms.EmailInput(attrs={'placeholder': 'reader@example.com'}),
            'phone': forms.TextInput(attrs={'placeholder': '+7 ...'}),
        }
