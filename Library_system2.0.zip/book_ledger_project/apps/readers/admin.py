from django.contrib import admin
from .models import Reader

@admin.register(Reader)
class ReaderAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'card_number', 'phone', 'email', 'active', 'registered_at')
    list_filter = ('active', 'registered_at')
    search_fields = ('full_name', 'card_number', 'phone', 'email')
    list_per_page = 25
