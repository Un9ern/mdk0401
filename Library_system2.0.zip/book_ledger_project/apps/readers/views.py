from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from apps.circulation.models import Loan
from .forms import ReaderForm
from .models import Reader

@login_required
def reader_list(request):
    query = request.GET.get('q', '').strip()
    status = request.GET.get('status', '').strip()
    readers = Reader.objects.all()
    if query:
        readers = readers.filter(Q(full_name__icontains=query) | Q(card_number__icontains=query) | Q(phone__icontains=query) | Q(email__icontains=query))
    if status == 'active':
        readers = readers.filter(active=True)
    elif status == 'inactive':
        readers = readers.filter(active=False)
    page_obj = Paginator(readers, 15).get_page(request.GET.get('page'))
    return render(request, 'readers/reader_list.html', {'page_obj': page_obj, 'query': query, 'status': status})

@login_required
def reader_create(request):
    form = ReaderForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        reader = form.save()
        messages.success(request, f'Читатель «{reader.full_name}» добавлен.')
        return redirect('reader-list')
    return render(request, 'readers/reader_form.html', {'form': form, 'page_title': 'Добавить читателя', 'submit_label': 'Добавить читателя'})

@login_required
def reader_edit(request, pk):
    reader = get_object_or_404(Reader, pk=pk)
    form = ReaderForm(request.POST or None, instance=reader)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Данные читателя сохранены.')
        return redirect('reader-list')
    return render(request, 'readers/reader_form.html', {'form': form, 'page_title': 'Карточка читателя', 'submit_label': 'Сохранить изменения', 'reader': reader})

@login_required
@require_POST
def reader_toggle(request, pk):
    reader = get_object_or_404(Reader, pk=pk)
    has_open_loan = Loan.objects.filter(reader=reader, returned_at__isnull=True).exists()
    if reader.active and has_open_loan:
        messages.error(request, 'Нельзя отключить читателя: за ним числятся выданные книги.')
    else:
        reader.active = not reader.active
        reader.save(update_fields=['active'])
        messages.success(request, 'Статус читателя обновлён.')
    return redirect('reader-list')
