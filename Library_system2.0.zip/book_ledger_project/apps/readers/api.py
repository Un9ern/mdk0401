from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Reader
from .serializers import ReaderSerializer

class ReaderViewSet(viewsets.ModelViewSet):
    queryset = Reader.objects.all().order_by('full_name')
    serializer_class = ReaderSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ['full_name', 'card_number', 'email', 'phone']
    ordering_fields = ['full_name', 'registered_at']
