from django.db import models

class Reader(models.Model):
    full_name = models.CharField('ФИО читателя', max_length=180)
    card_number = models.CharField('Номер читательского билета', max_length=30, unique=True)
    email = models.EmailField('Электронная почта', blank=True)
    phone = models.CharField('Телефон', max_length=30, blank=True)
    active = models.BooleanField('Обслуживание разрешено', default=True)
    registered_at = models.DateTimeField('Дата регистрации', auto_now_add=True)

    class Meta:
        ordering = ['full_name']
        verbose_name = 'Читатель'
        verbose_name_plural = 'Читатели'

    def __str__(self):
        return f'{self.full_name} ({self.card_number})'
