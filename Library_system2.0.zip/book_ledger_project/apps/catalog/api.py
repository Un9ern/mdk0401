from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Book
from .serializers import BookSerializer

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all().order_by('title', 'author')
    serializer_class = BookSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ['title', 'author', 'isbn', 'category']
    ordering_fields = ['title', 'author', 'publication_year', 'available_copies']
