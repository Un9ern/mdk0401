from django import forms
from django.core.exceptions import ValidationError
from .models import Book

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'category', 'publisher', 'publication_year', 'shelf', 'total_copies']
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'Например, Мастер и Маргарита'}),
            'author': forms.TextInput(attrs={'placeholder': 'Имя автора'}),
            'isbn': forms.TextInput(attrs={'placeholder': 'ISBN, если известен'}),
            'category': forms.TextInput(attrs={'placeholder': 'Художественная литература'}),
            'publisher': forms.TextInput(attrs={'placeholder': 'Издательство'}),
            'publication_year': forms.NumberInput(attrs={'min': 0, 'max': 2100}),
            'shelf': forms.TextInput(attrs={'placeholder': 'A-03'}),
            'total_copies': forms.NumberInput(attrs={'min': 1}),
        }

    def clean_isbn(self):
        value = self.cleaned_data.get('isbn')
        return value or None

    def clean_total_copies(self):
        value = self.cleaned_data['total_copies']
        if value < 1:
            raise ValidationError('Должен быть хотя бы один экземпляр.')
        if self.instance.pk:
            checked_out = self.instance.total_copies - self.instance.available_copies
            if value < checked_out:
                raise ValidationError(f'Сейчас выдано экземпляров: {checked_out}. Укажите не меньше этого числа.')
        return value
