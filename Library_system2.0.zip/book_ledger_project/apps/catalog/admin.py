from django.contrib import admin
from .models import Book

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'total_copies', 'available_copies', 'shelf')
    list_filter = ('category', 'publisher')
    search_fields = ('title', 'author', 'isbn')
    readonly_fields = ('available_copies', 'created_at', 'updated_at')
    list_per_page = 25
