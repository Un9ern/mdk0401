from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.db.models.deletion import ProtectedError
from .forms import BookForm
from .models import Book


def dashboard_redirect(request):
    return redirect('reports')

@login_required
def book_list(request):
    query = request.GET.get('q', '').strip()
    category = request.GET.get('category', '').strip()
    stock = request.GET.get('stock', '').strip()
    books = Book.objects.all()
    if query:
        books = books.filter(Q(title__icontains=query) | Q(author__icontains=query) | Q(isbn__icontains=query))
    if category:
        books = books.filter(category__iexact=category)
    if stock == 'available':
        books = books.filter(available_copies__gt=0)
    elif stock == 'empty':
        books = books.filter(available_copies=0)
    categories = Book.objects.order_by('category').values_list('category', flat=True).distinct()
    page_obj = Paginator(books, 15).get_page(request.GET.get('page'))
    return render(request, 'catalog/book_list.html', {'page_obj': page_obj, 'query': query, 'category': category, 'stock': stock, 'categories': categories})

@login_required
def book_create(request):
    form = BookForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        book = form.save()
        messages.success(request, f'Книга «{book.title}» добавлена в каталог.')
        return redirect('book-list')
    return render(request, 'catalog/book_form.html', {'form': form, 'page_title': 'Добавить книгу', 'submit_label': 'Добавить книгу'})

@login_required
def book_edit(request, pk):
    book = get_object_or_404(Book, pk=pk)
    form = BookForm(request.POST or None, instance=book)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Изменения сохранены.')
        return redirect('book-list')
    return render(request, 'catalog/book_form.html', {'form': form, 'page_title': 'Редактировать книгу', 'submit_label': 'Сохранить изменения', 'book': book})

@login_required
@require_POST
def book_delete(request, pk):
    book = get_object_or_404(Book, pk=pk)
    try:
        title = book.title
        book.delete()
        messages.success(request, f'Книга «{title}» удалена.')
    except ProtectedError:
        messages.error(request, 'Нельзя удалить книгу с историей выдачи. Вместо удаления оставьте её в каталоге или измените сведения.')
    return redirect('book-list')
