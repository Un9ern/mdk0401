from django.core.exceptions import ValidationError
from django.db import models

class Book(models.Model):
    title = models.CharField('Название', max_length=220)
    author = models.CharField('Автор', max_length=180)
    isbn = models.CharField('ISBN', max_length=20, blank=True, null=True, unique=True)
    category = models.CharField('Жанр / раздел', max_length=100, default='Без категории')
    publisher = models.CharField('Издательство', max_length=140, blank=True)
    publication_year = models.PositiveSmallIntegerField('Год издания', blank=True, null=True)
    shelf = models.CharField('Полка', max_length=30, blank=True)
    total_copies = models.PositiveIntegerField('Всего экземпляров', default=1)
    available_copies = models.PositiveIntegerField('Доступно', default=1, editable=False)
    created_at = models.DateTimeField('Добавлено', auto_now_add=True)
    updated_at = models.DateTimeField('Изменено', auto_now=True)

    class Meta:
        ordering = ['title', 'author']
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'

    def save(self, *args, **kwargs):
        if self.pk:
            old = type(self).objects.filter(pk=self.pk).values('total_copies', 'available_copies').first()
            if old:
                checked_out = old['total_copies'] - old['available_copies']
                new_available = self.total_copies - checked_out
                if new_available < 0:
                    raise ValidationError('Общее количество не может быть меньше числа выданных экземпляров.')
                self.available_copies = new_available
        else:
            self.available_copies = self.total_copies
        super().save(*args, **kwargs)

    @property
    def stock_label(self):
        if self.available_copies == 0:
            return 'Нет в наличии'
        if self.available_copies <= 2:
            return 'Мало экземпляров'
        return 'В наличии'

    def __str__(self):
        return f'{self.title} — {self.author}'
