from rest_framework import serializers
from .models import Book

class BookSerializer(serializers.ModelSerializer):
    stock_label = serializers.CharField(read_only=True)
    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'isbn', 'category', 'publisher', 'publication_year', 'shelf', 'total_copies', 'available_copies', 'stock_label', 'created_at', 'updated_at']
        read_only_fields = ['available_copies', 'created_at', 'updated_at']

    def validate_isbn(self, value):
        return value or None

    def validate_total_copies(self, value):
        if value < 1:
            raise serializers.ValidationError('Должен быть хотя бы один экземпляр.')
        if self.instance:
            checked_out = self.instance.total_copies - self.instance.available_copies
            if value < checked_out:
                raise serializers.ValidationError(f'Сейчас выдано экземпляров: {checked_out}.')
        return value

