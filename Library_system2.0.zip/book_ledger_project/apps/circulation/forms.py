from datetime import timedelta
from django import forms
from django.utils import timezone
from apps.catalog.models import Book
from apps.readers.models import Reader
from .models import Loan

class LoanForm(forms.ModelForm):
    class Meta:
        model = Loan
        fields = ['book', 'reader', 'due_date', 'notes']
        widgets = {
            'book': forms.Select(), 'reader': forms.Select(),
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'notes': forms.TextInput(attrs={'placeholder': 'Необязательное примечание'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['book'].queryset = Book.objects.filter(available_copies__gt=0).order_by('title')
        self.fields['reader'].queryset = Reader.objects.filter(active=True).order_by('full_name')
        self.fields['due_date'].initial = timezone.localdate() + timedelta(days=14)

    def clean_due_date(self):
        due_date = self.cleaned_data['due_date']
        if due_date < timezone.localdate():
            raise forms.ValidationError('Дата возврата не может быть в прошлом.')
        return due_date
