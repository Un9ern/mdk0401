from datetime import timedelta
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from apps.catalog.models import Book
from apps.readers.models import Reader
from .models import Loan
from .services import issue_book, return_book

class BookCirculationTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username='teststaff', password='test-password-123')
        self.book = Book.objects.create(title='Тестовая книга', author='Автор', category='Тест', total_copies=2)
        self.reader = Reader.objects.create(full_name='Тестовый читатель', card_number='TEST-001')

    def test_issue_reduces_available_stock(self):
        issue_book(book=self.book, reader=self.reader, due_date=timezone.localdate() + timedelta(days=14), issued_by=self.user)
        self.book.refresh_from_db()
        self.assertEqual(self.book.available_copies, 1)
        self.assertEqual(Loan.objects.filter(returned_at__isnull=True).count(), 1)

    def test_return_restores_available_stock(self):
        issue_book(book=self.book, reader=self.reader, due_date=timezone.localdate() + timedelta(days=14), issued_by=self.user)
        loan = Loan.objects.get()
        return_book(loan_id=loan.pk)
        self.book.refresh_from_db()
        loan.refresh_from_db()
        self.assertEqual(self.book.available_copies, 2)
        self.assertIsNotNone(loan.returned_at)

    def test_cannot_issue_when_no_stock(self):
        self.book.total_copies = 1
        self.book.save()
        issue_book(book=self.book, reader=self.reader, due_date=timezone.localdate() + timedelta(days=14))
        with self.assertRaises(ValidationError):
            issue_book(book=self.book, reader=self.reader, due_date=timezone.localdate() + timedelta(days=14))

    def test_inactive_reader_cannot_borrow(self):
        self.reader.active = False
        self.reader.save(update_fields=['active'])
        with self.assertRaises(ValidationError):
            issue_book(book=self.book, reader=self.reader, due_date=timezone.localdate() + timedelta(days=14))
