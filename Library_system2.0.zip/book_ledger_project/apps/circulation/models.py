from django.conf import settings
from django.db import models
from django.utils import timezone

class Loan(models.Model):
    book = models.ForeignKey('catalog.Book', on_delete=models.PROTECT, related_name='loans', verbose_name='Книга')
    reader = models.ForeignKey('readers.Reader', on_delete=models.PROTECT, related_name='loans', verbose_name='Читатель')
    issued_on = models.DateField('Дата выдачи', default=timezone.localdate)
    due_date = models.DateField('Вернуть до')
    returned_at = models.DateField('Дата возврата', blank=True, null=True)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, blank=True, null=True, verbose_name='Выдал сотрудник')
    notes = models.CharField('Примечание', max_length=240, blank=True)
    created_at = models.DateTimeField('Создано', auto_now_add=True)

    class Meta:
        ordering = ['-issued_on', '-id']
        verbose_name = 'Выдача'
        verbose_name_plural = 'Выдачи и возвраты'

    @property
    def status(self):
        if self.returned_at:
            return 'returned'
        if self.due_date < timezone.localdate():
            return 'overdue'
        return 'issued'

    @property
    def status_label(self):
        return {'returned': 'Возвращена', 'overdue': 'Просрочена', 'issued': 'На руках'}[self.status]

    def __str__(self):
        return f'{self.book.title} → {self.reader.full_name} ({self.issued_on})'
