from django.utils import timezone
from rest_framework import serializers
from rest_framework.exceptions import ValidationError as APIValidationError
from django.core.exceptions import ValidationError as DjangoValidationError
from apps.catalog.models import Book
from apps.readers.models import Reader
from .models import Loan
from .services import issue_book

class LoanSerializer(serializers.ModelSerializer):
    book_title = serializers.CharField(source='book.title', read_only=True)
    reader_name = serializers.CharField(source='reader.full_name', read_only=True)
    status = serializers.CharField(read_only=True)
    status_label = serializers.CharField(read_only=True)
    book = serializers.PrimaryKeyRelatedField(queryset=Book.objects.all())
    reader = serializers.PrimaryKeyRelatedField(queryset=Reader.objects.filter(active=True))

    class Meta:
        model = Loan
        fields = ['id', 'book', 'book_title', 'reader', 'reader_name', 'issued_on', 'due_date', 'returned_at', 'status', 'status_label', 'notes', 'issued_by', 'created_at']
        read_only_fields = ['issued_on', 'returned_at', 'issued_by', 'created_at']

    def validate_due_date(self, value):
        if value < timezone.localdate():
            raise serializers.ValidationError('Дата возврата не может быть в прошлом.')
        return value

    def create(self, validated_data):
        request = self.context.get('request')
        try:
            return issue_book(
                book=validated_data['book'], reader=validated_data['reader'],
                due_date=validated_data['due_date'], issued_by=getattr(request, 'user', None),
                notes=validated_data.get('notes', ''),
            )
        except DjangoValidationError as exc:
            raise APIValidationError({'detail': exc.messages}) from exc
