from django.core.exceptions import ValidationError
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.utils import timezone
from .models import Loan
from .serializers import LoanSerializer
from .services import return_book

class LoanViewSet(viewsets.ModelViewSet):
    queryset = Loan.objects.select_related('book', 'reader', 'issued_by').all()
    serializer_class = LoanSerializer
    permission_classes = [IsAuthenticated]
    search_fields = ['book__title', 'book__author', 'reader__full_name', 'reader__card_number']
    ordering_fields = ['issued_on', 'due_date', 'returned_at']

    @action(detail=True, methods=['post'], url_path='return')
    def mark_returned(self, request, pk=None):
        try:
            loan = return_book(loan_id=pk)
        except (ValidationError, Loan.DoesNotExist) as exc:
            detail = exc.messages[0] if hasattr(exc, 'messages') else 'Запись не найдена.'
            return Response({'detail': detail}, status=status.HTTP_400_BAD_REQUEST)
        return Response(self.get_serializer(loan).data, status=status.HTTP_200_OK)
