from django.contrib import admin
from .models import Loan

@admin.register(Loan)
class LoanAdmin(admin.ModelAdmin):
    list_display = ('book', 'reader', 'issued_on', 'due_date', 'returned_at', 'display_status')
    list_filter = ('issued_on', 'due_date', 'returned_at')
    search_fields = ('book__title', 'reader__full_name', 'reader__card_number')
    readonly_fields = ('issued_on', 'returned_at', 'created_at')
    list_select_related = ('book', 'reader')

    @admin.display(description='Статус')
    def display_status(self, obj):
        return obj.status_label
