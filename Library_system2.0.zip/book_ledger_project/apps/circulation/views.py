from datetime import timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from .forms import LoanForm
from .models import Loan
from .services import issue_book, return_book

@login_required
def loan_list(request):
    query = request.GET.get('q', '').strip()
    status = request.GET.get('status', '').strip()
    loans = Loan.objects.select_related('book', 'reader', 'issued_by').all()
    if query:
        loans = loans.filter(Q(book__title__icontains=query) | Q(book__author__icontains=query) | Q(reader__full_name__icontains=query) | Q(reader__card_number__icontains=query))
    today = timezone.localdate()
    if status == 'issued':
        loans = loans.filter(returned_at__isnull=True, due_date__gte=today)
    elif status == 'overdue':
        loans = loans.filter(returned_at__isnull=True, due_date__lt=today)
    elif status == 'returned':
        loans = loans.filter(returned_at__isnull=False)
    page_obj = Paginator(loans, 15).get_page(request.GET.get('page'))
    return render(request, 'circulation/loan_list.html', {'page_obj': page_obj, 'query': query, 'status': status})

@login_required
def loan_create(request):
    form = LoanForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        try:
            data = form.cleaned_data
            issue_book(book=data['book'], reader=data['reader'], due_date=data['due_date'], issued_by=request.user, notes=data.get('notes', ''))
            messages.success(request, 'Выдача зарегистрирована. Доступное количество обновлено.')
            return redirect('loan-list')
        except ValidationError as exc:
            form.add_error(None, exc.messages[0] if hasattr(exc, 'messages') else str(exc))
    return render(request, 'circulation/loan_form.html', {'form': form, 'page_title': 'Выдать книгу', 'submit_label': 'Подтвердить выдачу'})

@login_required
@require_POST
def loan_return(request, pk):
    try:
        loan = return_book(loan_id=pk)
        messages.success(request, f'Возврат книги «{loan.book.title}» зарегистрирован.')
    except (ValidationError, Loan.DoesNotExist) as exc:
        messages.error(request, exc.messages[0] if hasattr(exc, 'messages') else 'Запись о выдаче не найдена.')
    return redirect('loan-list')
