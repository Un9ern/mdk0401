from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F
from django.utils import timezone
from apps.catalog.models import Book
from apps.readers.models import Reader
from .models import Loan

@transaction.atomic
def issue_book(*, book, reader, due_date, issued_by=None, notes=''):
    book = Book.objects.select_for_update().get(pk=book.pk)
    reader = Reader.objects.get(pk=reader.pk)
    if not reader.active:
        raise ValidationError('Выдача невозможна: обслуживание читателя отключено.')
    if book.available_copies < 1:
        raise ValidationError('Нет свободных экземпляров этой книги.')
    today = timezone.localdate()
    if due_date < today:
        raise ValidationError('Дата возврата не может быть в прошлом.')
    loan = Loan.objects.create(book=book, reader=reader, issued_by=issued_by, issued_on=today, due_date=due_date, notes=notes)
    Book.objects.filter(pk=book.pk).update(available_copies=F('available_copies') - 1)
    return loan

@transaction.atomic
def return_book(*, loan_id):
    loan = Loan.objects.select_for_update().select_related('book').get(pk=loan_id)
    if loan.returned_at:
        raise ValidationError('Эта книга уже отмечена как возвращённая.')
    today = timezone.localdate()
    loan.returned_at = today
    loan.save(update_fields=['returned_at'])
    Book.objects.filter(pk=loan.book_id).update(available_copies=F('available_copies') + 1)
    return loan
